TERTIB DISHUB WEBSITE

File utama: index.html

Cara online gratis via GitHub Pages:
1. Buat repository baru di GitHub.
2. Upload index.html ke repository.
3. Buka Settings > Pages.
4. Pada Build and deployment pilih Deploy from a branch.
5. Pilih branch main dan folder / (root), lalu Save.
6. Tunggu proses selesai. GitHub akan memberikan link website.
